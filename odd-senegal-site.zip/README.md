# ODD Sénégal — Site Open SDG

Plateforme nationale de suivi des Objectifs de Développement Durable au Sénégal.

**URL :** https://ndaosaer.github.io/odd-senegal-site/

Inspirée de la [plateforme canadienne CIF](https://sdgcif-data-canada-oddcic-donnee.github.io/fr/).
Construite avec [Open SDG](https://open-sdg.org/).

## Structure

```
odd-senegal-site/          ← CE dépôt (site)
  _config.yml              ← Configuration principale
  Gemfile                  ← Dépendances Ruby/Jekyll
  .github/workflows/       ← Déploiement automatique GitHub Actions

odd-senegal-data/          ← Dépôt séparé (données)
  data/indicator_X-1-1.csv ← Données par ODD
  meta/X-1-1.yml           ← Métadonnées par ODD
  scripts/build.py         ← Script de compilation
```

## Mise à jour des données

1. Aller dans le dépôt **odd-senegal-data**
2. Remplacer le CSV concerné dans `data/`
3. `git add . && git commit -m "Maj données ODD X" && git push`
4. GitHub Actions recompile et déploie automatiquement (3-5 minutes)

## Développement local

```bash
gem install bundler
bundle install
bundle exec jekyll serve
```

## Auteur

ANSD / DMCI — Mémoire Analyste Statisticien, Dakar 2025
